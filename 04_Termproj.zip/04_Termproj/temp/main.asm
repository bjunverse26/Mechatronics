;******************************************************************************
;* TMS320C6x ANSI C Codegen                                      Version 4.10 *
;* Date/Time created: Wed May 27 12:38:22 2026                                *
;******************************************************************************

;******************************************************************************
;* GLOBAL FILE PARAMETERS                                                     *
;*                                                                            *
;*   Architecture      : TMS320C670x                                          *
;*   Optimization      : Disabled                                             *
;*   Optimizing for    : Compile time, Ease of Development                    *
;*                       Based on options: no -o, no -ms                      *
;*   Endian            : Little                                               *
;*   Interrupt Thrshld : Disabled                                             *
;*   Memory Model      : Large                                                *
;*   Calls to RTS      : Far                                                  *
;*   Pipelining        : Disabled                                             *
;*   Memory Aliases    : Presume are aliases (pessimistic)                    *
;*   Debug Info        : No Debug Info                                        *
;*                                                                            *
;******************************************************************************

	.asg	A15, FP
	.asg	B14, DP
	.asg	B15, SP
	.global	$bss

	.global	_TINTCnt
_TINTCnt:	.usect	.far,4,4
;	acp6x -q -D_FAR_RTS=1 --large_model=3 --version=6701 -m --i_output_file C:\Users\W10\AppData\Local\Temp\TI5264_2 --template_info_file C:\Users\W10\AppData\Local\Temp\TI5264_3 --object_file main.obj --opt_shell 9 main.c -as -k -mr1 -ml3 -q -fstemp -fftemp -mv6701 main.c 
	.sect	".text"
	.global	_InitEXINTF

;******************************************************************************
;* FUNCTION NAME: _InitEXINTF                                                 *
;*                                                                            *
;*   Regs Modified     : A0,A3,A4,B4,B5,B6                                    *
;*   Regs Used         : A0,A3,A4,B3,B4,B5,B6                                 *
;*   Local Frame Size  : 0 Args + 0 Auto + 0 Save = 0 byte                    *
;******************************************************************************
_InitEXINTF:
;** --------------------------------------------------------------------------*
           ZERO    .D1     A0                ; |18| 
           MVKH    .S1     0x1800000,A0      ; |18| 
           LDW     .D1T1   *A0,A4            ; |18| 
           MVKL    .S2     0x1800008,B5      ; |21| 
           MVKL    .S2     0x22120821,B6     ; |33| 
           B       .S2     B3                ; |43| 

           MVKL    .S2     0x1800010,B4      ; |33| 
||         MVKL    .S1     0xd00321,A3       ; |21| 

           CLR     .S1     A4,3,5,A4         ; |18| 
||         MVKH    .S2     0x1800008,B5      ; |21| 

           STW     .D1T1   A4,*A0            ; |18| 
||         MVKH    .S2     0x22120821,B6     ; |33| 
||         MVKH    .S1     0xd00321,A3       ; |21| 

           STW     .D2T1   A3,*B5            ; |21| 
||         MVKH    .S2     0x1800010,B4      ; |33| 

           STW     .D2T2   B6,*B4            ; |33| 
           ; BRANCH OCCURS                   ; |43| 


	.sect	".text"
	.global	_InitTimer

;******************************************************************************
;* FUNCTION NAME: _InitTimer                                                  *
;*                                                                            *
;*   Regs Modified     : A0,A3,B4,B5                                          *
;*   Regs Used         : A0,A3,B3,B4,B5                                       *
;*   Local Frame Size  : 0 Args + 0 Auto + 0 Save = 0 byte                    *
;******************************************************************************
_InitTimer:
;** --------------------------------------------------------------------------*
           ZERO    .D2     B4                ; |48| 
           MVKH    .S2     0x1940000,B4      ; |48| 
           LDW     .D2T2   *B4,B5            ; |48| 
           MVKL    .S1     0x1940004,A0      ; |51| 
           MVKH    .S1     0x1940004,A0      ; |51| 
           ZERO    .D1     A3                ; |54| 
           MVKH    .S1     0x1940000,A3      ; |54| 
           SET     .S2     B5,8,9,B5         ; |48| 

           MVK     .S2     20000,B4          ; |51| 
||         STW     .D2T2   B5,*B4            ; |48| 

           STW     .D1T2   B4,*A0            ; |51| 
           LDW     .D1T1   *A3,A0            ; |54| 
           B       .S2     B3                ; |55| 
           NOP             3
           SET     .S1     A0,6,7,A0         ; |54| 
           STW     .D1T1   A0,*A3            ; |54| 
           ; BRANCH OCCURS                   ; |55| 


	.sect	".text"
	.global	_InitINT

;******************************************************************************
;* FUNCTION NAME: _InitINT                                                    *
;*                                                                            *
;*   Regs Modified     : A0,B4                                                *
;*   Regs Used         : A0,B3,B4                                             *
;*   Local Frame Size  : 0 Args + 0 Auto + 0 Save = 0 byte                    *
;******************************************************************************
_InitINT:
;** --------------------------------------------------------------------------*
           MVC     .S2     IER,B4            ; |60| 
           MVK     .S1     16450,A0          ; |60| 
           OR      .S2X    A0,B4,B4          ; |60| 
           MVC     .S2     B4,IER            ; |60| 
           B       .S2     B3                ; |61| 
           NOP             5
           ; BRANCH OCCURS                   ; |61| 


	.sect	".text"
	.global	_GIE

;******************************************************************************
;* FUNCTION NAME: _GIE                                                        *
;*                                                                            *
;*   Regs Modified     : B4                                                   *
;*   Regs Used         : B3,B4                                                *
;*   Local Frame Size  : 0 Args + 0 Auto + 0 Save = 0 byte                    *
;******************************************************************************
_GIE:
;** --------------------------------------------------------------------------*
           MVC     .S2     CSR,B4            ; |66| 
           OR      .S2     1,B4,B4           ; |66| 
           MVC     .S2     B4,CSR            ; |66| 
           B       .S2     B3                ; |67| 
           NOP             5
           ; BRANCH OCCURS                   ; |67| 


	.sect	".text"
	.global	_delay_us

;******************************************************************************
;* FUNCTION NAME: _delay_us                                                   *
;*                                                                            *
;*   Regs Modified     : B0,B4,B5,B6,SP                                       *
;*   Regs Used         : A4,B0,B3,B4,B5,B6,SP                                 *
;*   Local Frame Size  : 0 Args + 4 Auto + 0 Save = 4 byte                    *
;******************************************************************************
_delay_us:
;** --------------------------------------------------------------------------*
           MV      .S2X    A4,B4             ; |71| 
           SHL     .S2     B4,4,B5           ; |74| 

           ZERO    .S2     B4                ; |74| 
||         SUBAH   .D2     B5,B4,B5          ; |74| 

           CMPLTU  .L2     B4,B5,B0          ; |74| 
   [!B0]   B       .S1     L2                ; |74| 
           SUB     .D2     SP,8,SP           ; |71| 
           STW     .D2T1   A4,*+SP(4)        ; |71| 
   [ B0]   LDW     .D2T2   *+SP(4),B5        ; |74| 
           NOP             2
           ; BRANCH OCCURS                   ; |74| 
;** --------------------------------------------------------------------------*
           NOP             2
;*----------------------------------------------------------------------------*
;*   SOFTWARE PIPELINE INFORMATION
;*      Disqualified loop: software pipelining disabled
;*----------------------------------------------------------------------------*
L1:    
           SHL     .S2     B5,4,B6           ; |74| 

           SUBAH   .D2     B6,B5,B5          ; |74| 
||         ADD     .S2     1,B4,B4           ; |74| 

           CMPLTU  .L2     B4,B5,B0          ; |74| 
   [ B0]   B       .S1     L1                ; |74| 
   [ B0]   LDW     .D2T2   *+SP(4),B5        ; |74| 
           NOP             4
           ; BRANCH OCCURS                   ; |74| 
;** --------------------------------------------------------------------------*
L2:    
           B       .S2     B3                ; |75| 
           ADD     .D2     8,SP,SP           ; |75| 
           NOP             4
           ; BRANCH OCCURS                   ; |75| 


	.sect	".text"
	.global	_delay_ms

;******************************************************************************
;* FUNCTION NAME: _delay_ms                                                   *
;*                                                                            *
;*   Regs Modified     : A4,B0,B3,B4,B5,B6,B7,B9,SP                           *
;*   Regs Used         : A4,B0,B3,B4,B5,B6,B7,B9,SP                           *
;*   Local Frame Size  : 0 Args + 4 Auto + 0 Save = 4 byte                    *
;******************************************************************************
_delay_ms:
;** --------------------------------------------------------------------------*
           ZERO    .D2     B7                ; |82| 
           CMPLTU  .L2X    B7,A4,B0
   [!B0]   B       .S1     L4                ; |82| 
           SUB     .D2     SP,8,SP           ; |79| 
           STW     .D2T1   A4,*+SP(4)        ; |79| 
           MV      .L2     B3,B9             ; |79| 
   [ B0]   MVKL    .S2     _delay_us,B4      ; |83| 
   [ B0]   MVKH    .S2     _delay_us,B4      ; |83| 
           ; BRANCH OCCURS                   ; |82| 
;*----------------------------------------------------------------------------*
;*   SOFTWARE PIPELINE INFORMATION
;*      Disqualified loop: software pipelining disabled
;*----------------------------------------------------------------------------*
L3:    
           B       .S2     B4                ; |83| 
           MVKL    .S2     RL0,B3            ; |83| 
           MVKH    .S2     RL0,B3            ; |83| 
           MVK     .S1     0x3e8,A4          ; |83| 
           NOP             2
RL0:       ; CALL OCCURS                     ; |83| 
           LDW     .D2T2   *+SP(4),B4        ; |84| 
           ADD     .D2     1,B7,B7           ; |84| 
           NOP             3
           CMPLTU  .L2     B7,B4,B0          ; |84| 
   [ B0]   B       .S1     L3                ; |84| 
   [ B0]   MVKL    .S2     _delay_us,B4      ; |83| 
   [ B0]   MVKH    .S2     _delay_us,B4      ; |83| 
           NOP             3
           ; BRANCH OCCURS                   ; |84| 
;** --------------------------------------------------------------------------*
L4:    
           B       .S2     B9                ; |85| 
           ADD     .D2     8,SP,SP           ; |85| 
           NOP             4
           ; BRANCH OCCURS                   ; |85| 


	.sect	".text"
	.global	_WaitTFlag

;******************************************************************************
;* FUNCTION NAME: _WaitTFlag                                                  *
;*                                                                            *
;*   Regs Modified     : A0,A1,A3                                             *
;*   Regs Used         : A0,A1,A3,B3                                          *
;*   Local Frame Size  : 0 Args + 0 Auto + 0 Save = 0 byte                    *
;******************************************************************************
_WaitTFlag:
;** --------------------------------------------------------------------------*
           MVKL    .S1     _TFlag,A0         ; |90| 
           MVKH    .S1     _TFlag,A0         ; |90| 
           LDW     .D1T1   *A0,A1            ; |90| 
           NOP             4
   [ A1]   B       .S1     L6                ; |90| 
   [!A1]   MVKL    .S1     _TFlag,A0         ; |90| 
   [!A1]   MVKH    .S1     _TFlag,A0         ; |90| 
   [!A1]   LDW     .D1T1   *A0,A1            ; |90| 
           NOP             2
           ; BRANCH OCCURS                   ; |90| 
;*----------------------------------------------------------------------------*
;*   SOFTWARE PIPELINE INFORMATION
;*      Disqualified loop: software pipelining disabled
;*----------------------------------------------------------------------------*
L5:    
           NOP             2
   [!A1]   B       .S1     L5                ; |90| 
   [!A1]   MVKL    .S1     _TFlag,A0         ; |90| 
   [!A1]   MVKH    .S1     _TFlag,A0         ; |90| 
   [!A1]   LDW     .D1T1   *A0,A1            ; |90| 
           NOP             2
           ; BRANCH OCCURS                   ; |90| 
;** --------------------------------------------------------------------------*
L6:    
           B       .S2     B3                ; |92| 
           MVKL    .S1     _TFlag,A0         ; |91| 
           MVKH    .S1     _TFlag,A0         ; |91| 
           ZERO    .D1     A3                ; |91| 
           STW     .D1T1   A3,*A0            ; |91| 
           NOP             1
           ; BRANCH OCCURS                   ; |92| 


	.sect	".text"
	.global	_WaitTFlagCnt

;******************************************************************************
;* FUNCTION NAME: _WaitTFlagCnt                                               *
;*                                                                            *
;*   Regs Modified     : A0,A1,A3,B0,B3,B4,B5,B9,SP                           *
;*   Regs Used         : A0,A1,A3,A4,B0,B3,B4,B5,B9,SP                        *
;*   Local Frame Size  : 0 Args + 8 Auto + 0 Save = 8 byte                    *
;******************************************************************************
_WaitTFlagCnt:
;** --------------------------------------------------------------------------*

           SUB     .D2     SP,8,SP           ; |96| 
||         MVKL    .S1     _TFlag,A0         ; |99| 

           STW     .D2T1   A4,*+SP(4)        ; |96| 
||         MVKH    .S1     _TFlag,A0         ; |99| 
||         ZERO    .D1     A3                ; |99| 

           STW     .D1T1   A3,*A0            ; |99| 
           LDW     .D2T2   *+SP(4),B5        ; |101| 
           ZERO    .D2     B4                ; |101| 
           STW     .D2T2   B4,*+SP(8)        ; |101| 
           MV      .S2     B3,B9             ; |96| 
           NOP             1
           CMPLTU  .L2     B4,B5,B0          ; |101| 
   [!B0]   B       .S1     L8                ; |101| 
   [ B0]   MVKL    .S1     _WaitTFlag,A0     ; |102| 
   [ B0]   MVKH    .S1     _WaitTFlag,A0     ; |102| 
           NOP             3
           ; BRANCH OCCURS                   ; |101| 
;*----------------------------------------------------------------------------*
;*   SOFTWARE PIPELINE INFORMATION
;*      Disqualified loop: software pipelining disabled
;*----------------------------------------------------------------------------*
L7:    
           B       .S2X    A0                ; |102| 
           MVKL    .S2     RL2,B3            ; |102| 
           MVKH    .S2     RL2,B3            ; |102| 
           NOP             3
RL2:       ; CALL OCCURS                     ; |102| 
           LDW     .D2T2   *+SP(8),B4        ; |103| 
           LDW     .D2T2   *+SP(4),B5        ; |103| 
           NOP             3
           ADD     .D2     1,B4,B4           ; |103| 
           CMPLTU  .L2     B4,B5,B0          ; |103| 
   [ B0]   B       .S1     L7                ; |103| 
           STW     .D2T2   B4,*+SP(8)        ; |103| 
   [ B0]   MVKL    .S1     _WaitTFlag,A0     ; |102| 
   [ B0]   MVKH    .S1     _WaitTFlag,A0     ; |102| 
           NOP             2
           ; BRANCH OCCURS                   ; |103| 
;** --------------------------------------------------------------------------*
L8:    
           B       .S2     B9                ; |104| 
           ADD     .D2     8,SP,SP           ; |104| 
           NOP             4
           ; BRANCH OCCURS                   ; |104| 


	.sect	".text"
	.global	_PWMOut

;******************************************************************************
;* FUNCTION NAME: _PWMOut                                                     *
;*                                                                            *
;*   Regs Modified     : A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,B0,B1,B2,B3,B4,B5,B6,  *
;*                           B7,B8,B9,SP                                      *
;*   Regs Used         : A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,B0,B1,B2,B3,B4,B5,B6,  *
;*                           B7,B8,B9,SP                                      *
;*   Local Frame Size  : 0 Args + 8 Auto + 4 Save = 12 byte                   *
;******************************************************************************
_PWMOut:
;** --------------------------------------------------------------------------*
           ZERO    .D1     A3                ; |113| 

           MVKH    .S1     0x42480000,A3     ; |113| 
||         ZERO    .D1     A0                ; |113| 

           MVKH    .S1     0x42480000,A0     ; |113| 
||         STW     .D2T2   B3,*SP--(16)      ; |109| 
||         MV      .S2X    A4,B4             ; |109| 

           CMPGTSP .S1X    B4,A3,A1          ; |113| 
||         STW     .D2T1   A4,*+SP(4)        ; |109| 

   [ A1]   STW     .D2T1   A0,*+SP(4)        ; |113| 
           LDW     .D2T2   *+SP(4),B5        ; |114| 
           ZERO    .D2     B4                ; |114| 
           ZERO    .D1     A0                ; |114| 
           MVKH    .S2     0xc2480000,B4     ; |114| 
           MVKH    .S1     0xc2480000,A0     ; |114| 
           CMPLTSP .S2     B5,B4,B0          ; |114| 
   [ B0]   STW     .D2T1   A0,*+SP(4)        ; |114| 
           LDW     .D2T2   *+SP(4),B4        ; |116| 
           ZERO    .D1     A0                ; |116| 
           MVKH    .S1     0x42480000,A0     ; |116| 
           MVKL    .S2     __divf,B5         ; |116| 
           MVKH    .S2     __divf,B5         ; |116| 
           ADDSP   .L2X    A0,B4,B6          ; |116| 
           MVKL    .S2     0x457ff000,B4     ; |116| 
           MVKH    .S2     0x457ff000,B4     ; |116| 
           B       .S2     B5                ; |116| 
           MPYSP   .M2     B4,B6,B6          ; |116| 
           ZERO    .D1     A0                ; |116| 
           ZERO    .D2     B4                ; |111| 

           MVKH    .S1     0x42c80000,A0     ; |116| 
||         MVKL    .S2     RL4,B3            ; |116| 

           MV      .L2X    A0,B4             ; |116| 
||         STW     .D2T2   B4,*+SP(8)        ; |111| 
||         MV      .S1X    B6,A4             ; |116| 
||         MVKH    .S2     RL4,B3            ; |116| 

RL4:       ; CALL OCCURS                     ; |116| 
           ZERO    .D2     B4                ; |116| 
           MVKH    .S2     0x3f000000,B4     ; |116| 
           ADDSP   .L1X    B4,A4,A0          ; |116| 
           NOP             3
           SPTRUNC .L1     A0,A0             ; |116| 
           NOP             3
           STW     .D2T1   A0,*+SP(8)        ; |116| 
           LDW     .D2T2   *+SP(8),B4        ; |117| 
           MVKL    .S1     0x2000088,A0      ; |117| 
           MVKH    .S1     0x2000088,A0      ; |117| 
           NOP             2
           STW     .D1T2   B4,*A0            ; |117| 
           LDW     .D2T2   *++SP(16),B3      ; |118| 
           NOP             4
           B       .S2     B3                ; |118| 
           NOP             5
           ; BRANCH OCCURS                   ; |118| 


	.sect	".text"
	.global	_GetPendAngle

;******************************************************************************
;* FUNCTION NAME: _GetPendAngle                                               *
;*                                                                            *
;*   Regs Modified     : A0,A1,A2,A4,A5,A6,B0,B1,B2,B3,B4,B9,SP               *
;*   Regs Used         : A0,A1,A2,A4,A5,A6,B0,B1,B2,B3,B4,B9,SP               *
;*   Local Frame Size  : 0 Args + 8 Auto + 0 Save = 8 byte                    *
;******************************************************************************
_GetPendAngle:
;** --------------------------------------------------------------------------*
           MVKL    .S2     0x20000ac,B4      ; |122| 
           MVKH    .S2     0x20000ac,B4      ; |122| 
           LDW     .D2T2   *B4,B4            ; |122| 
           SUB     .D2     SP,8,SP           ; |120| 
           ZERO    .D1     A0                ; |124| 
           MVKH    .S1     0xbeb40000,A0     ; |124| 
           MV      .D2     B3,B9             ; |120| 

           INTSP   .L2     B4,B4             ; |124| 
||         STW     .D2T2   B4,*+SP(8)        ; |122| 

           MVKL    .S2     RL6,B3            ; |125| 
           MVKH    .S2     RL6,B3            ; |125| 
           NOP             1
           MPYSP   .M1X    A0,B4,A0          ; |124| 
           MVK     .S2     0x168,B4          ; |125| 
           NOP             2
           SPTRUNC .L1     A0,A0             ; |124| 
           NOP             3

           MVKL    .S1     __remi,A0         ; |125| 
||         STW     .D2T1   A0,*+SP(4)        ; |124| 
||         MV      .D1     A0,A4             ; |124| 

           MVKH    .S1     __remi,A0         ; |125| 
           B       .S2X    A0                ; |125| 
           NOP             5
RL6:       ; CALL OCCURS                     ; |125| 
           B       .S2     B9                ; |128| 
           STW     .D2T1   A4,*+SP(4)        ; |125| 
           ADD     .S2     8,SP,SP           ; |128| 
           NOP             3
           ; BRANCH OCCURS                   ; |128| 


	.sect	".text"
	.global	_main

;******************************************************************************
;* FUNCTION NAME: _main                                                       *
;*                                                                            *
;*   Regs Modified     : A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,B0,B1,B2,B3,B4,B5,B6,  *
;*                           B7,B8,B9,SP                                      *
;*   Regs Used         : A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,B0,B1,B2,B3,B4,B5,B6,  *
;*                           B7,B8,B9,SP                                      *
;*   Local Frame Size  : 16 Args + 8 Auto + 4 Save = 28 byte                  *
;******************************************************************************
_main:
;** --------------------------------------------------------------------------*
           MVKL    .S1     _InitEXINTF,A0    ; |137| 
           MVKH    .S1     _InitEXINTF,A0    ; |137| 
           B       .S2X    A0                ; |137| 
           STW     .D2T2   B3,*SP--(32)      ; |133| 
           MVKL    .S2     RL8,B3            ; |137| 
           MVKH    .S2     RL8,B3            ; |137| 
           NOP             2
RL8:       ; CALL OCCURS                     ; |137| 
           MVKL    .S1     _InitTimer,A0     ; |138| 
           MVKH    .S1     _InitTimer,A0     ; |138| 
           B       .S2X    A0                ; |138| 
           MVKL    .S2     RL10,B3           ; |138| 
           MVKH    .S2     RL10,B3           ; |138| 
           NOP             3
RL10:      ; CALL OCCURS                     ; |138| 
           MVKL    .S2     _InitUART,B4      ; |139| 
           MVKH    .S2     _InitUART,B4      ; |139| 
           B       .S2     B4                ; |139| 
           MVKL    .S2     RL12,B3           ; |139| 
           MVKH    .S2     RL12,B3           ; |139| 
           NOP             3
RL12:      ; CALL OCCURS                     ; |139| 
           MVKL    .S1     _InitINT,A0       ; |140| 
           MVKH    .S1     _InitINT,A0       ; |140| 
           B       .S2X    A0                ; |140| 
           MVKL    .S2     RL14,B3           ; |140| 
           MVKH    .S2     RL14,B3           ; |140| 
           NOP             3
RL14:      ; CALL OCCURS                     ; |140| 
           MVKL    .S1     _InitUSBMon,A0    ; |141| 
           MVKH    .S1     _InitUSBMon,A0    ; |141| 
           B       .S2X    A0                ; |141| 
           MVKL    .S2     RL16,B3           ; |141| 
           MVKH    .S2     RL16,B3           ; |141| 
           NOP             3
RL16:      ; CALL OCCURS                     ; |141| 
           MVKL    .S1     _sprintf,A0       ; |143| 

           MVKH    .S1     _sprintf,A0       ; |143| 
||         MVKL    .S2     SL1+0,B5          ; |143| 

           B       .S2X    A0                ; |143| 
           MVKL    .S2     RL18,B3           ; |143| 
           MVKH    .S2     SL1+0,B5          ; |143| 
           MVKL    .S2     _tmp_string,B4    ; |143| 
           MVKH    .S2     _tmp_string,B4    ; |143| 

           MVKH    .S2     RL18,B3           ; |143| 
||         STW     .D2T2   B5,*+SP(4)        ; |143| 
||         MV      .S1X    B4,A4             ; |143| 

RL18:      ; CALL OCCURS                     ; |143| 
           MVKL    .S1     _Report,A0        ; |143| 
           MVKH    .S1     _Report,A0        ; |143| 
           B       .S2X    A0                ; |143| 
           MVKL    .S2     RL20,B3           ; |143| 
           MVKH    .S2     RL20,B3           ; |143| 
           NOP             3
RL20:      ; CALL OCCURS                     ; |143| 
           MVK     .S1     2026,A0           ; |144| 

           MVKL    .S1     _sprintf,A0       ; |144| 
||         STW     .D2T1   A0,*+SP(8)        ; |144| 

           MVKH    .S1     _sprintf,A0       ; |144| 
||         MVKL    .S2     _tmp_string,B5    ; |144| 

           B       .S2X    A0                ; |144| 
           MVKL    .S2     SL2+0,B4          ; |144| 
           MVKH    .S2     _tmp_string,B5    ; |144| 
           MVKH    .S2     SL2+0,B4          ; |144| 
           MVKL    .S2     RL22,B3           ; |144| 

           MVKH    .S2     RL22,B3           ; |144| 
||         STW     .D2T2   B4,*+SP(4)        ; |144| 
||         MV      .S1X    B5,A4             ; |144| 

RL22:      ; CALL OCCURS                     ; |144| 
           MVKL    .S1     _Report,A0        ; |144| 
           MVKH    .S1     _Report,A0        ; |144| 
           B       .S2X    A0                ; |144| 
           MVKL    .S2     RL24,B3           ; |144| 
           MVKH    .S2     RL24,B3           ; |144| 
           NOP             3
RL24:      ; CALL OCCURS                     ; |144| 
           MVKL    .S2     SL3+0,B5          ; |145| 
           MVKH    .S2     SL3+0,B5          ; |145| 
           MVKL    .S2     0x20003fc,B4      ; |145| 

           STW     .D2T2   B5,*+SP(4)        ; |145| 
||         MVKH    .S2     0x20003fc,B4      ; |145| 

           LDW     .D2T2   *B4,B4            ; |145| 
           MVKL    .S1     0x20003fc,A0      ; |145| 
           MVKH    .S1     0x20003fc,A0      ; |145| 
           MVKL    .S1     _tmp_string,A4    ; |145| 
           MVKL    .S2     RL26,B3           ; |145| 
           EXTU    .S2     B4,16,24,B4       ; |145| 
           STW     .D2T2   B4,*+SP(8)        ; |145| 

           MVKL    .S1     _sprintf,A0       ; |145| 
||         LDW     .D1T1   *A0,A3            ; |145| 

           MVKH    .S1     _sprintf,A0       ; |145| 
           B       .S2X    A0                ; |145| 
           MVKH    .S1     _tmp_string,A4    ; |145| 
           MVKH    .S2     RL26,B3           ; |145| 
           EXTU    .S1     A3,24,24,A3       ; |145| 
           STW     .D2T1   A3,*+SP(12)       ; |145| 
           NOP             1
RL26:      ; CALL OCCURS                     ; |145| 
           MVKL    .S1     _Report,A0        ; |145| 
           MVKH    .S1     _Report,A0        ; |145| 
           B       .S2X    A0                ; |145| 
           MVKL    .S2     RL28,B3           ; |145| 
           MVKH    .S2     RL28,B3           ; |145| 
           NOP             3
RL28:      ; CALL OCCURS                     ; |145| 
;** --------------------------------------------------------------------------*
           MVKL    .S2     _GIE,B8           ; |157| 
           MVKL    .S2     _TINTCnt,B6       ; |148| 

           MVKL    .S2     0x200004c,B5      ; |150| 
||         MVKL    .S1     _TFlag,A0         ; |147| 

           MVKH    .S2     _GIE,B8           ; |157| 
||         MVK     .S1     1,A3              ; |150| 

           MVKH    .S2     _TINTCnt,B6       ; |148| 
||         MVKH    .S1     _TFlag,A0         ; |147| 
||         ZERO    .D1     A4                ; |147| 

           B       .S2     B8                ; |157| 
||         MVKL    .S1     0x2000090,A4      ; |152| 
||         STW     .D1T1   A4,*A0            ; |147| 
||         ZERO    .D2     B7                ; |148| 

           MVKH    .S1     0x2000090,A4      ; |152| 
||         STW     .D2T2   B7,*B6            ; |148| 
||         MVKH    .S2     0x200004c,B5      ; |150| 

           ZERO    .D1     A3                ; |152| 
||         STW     .D2T1   A3,*B5            ; |150| 
||         MVKL    .S1     0x2000080,A0      ; |155| 
||         MVKL    .S2     0x200008c,B4      ; |153| 

           STW     .D1T1   A3,*A4            ; |152| 
||         ZERO    .D2     B5                ; |153| 
||         MVKH    .S1     0x2000080,A0      ; |155| 
||         MVKH    .S2     0x200008c,B4      ; |153| 

           STW     .D2T2   B5,*B4            ; |153| 
||         MVK     .S1     1,A3              ; |155| 
||         MVKL    .S2     RL30,B3           ; |157| 

           STW     .D1T1   A3,*A0            ; |155| 
||         MVKH    .S2     RL30,B3           ; |157| 

RL30:      ; CALL OCCURS                     ; |157| 
           MVKL    .S1     _WaitTFlagCnt,A0  ; |159| 
           MVKH    .S1     _WaitTFlagCnt,A0  ; |159| 
           B       .S2X    A0                ; |159| 
           MVKL    .S2     RL32,B3           ; |159| 
           MVKH    .S2     RL32,B3           ; |159| 
           MVK     .S1     0x64,A4           ; |159| 
           NOP             2
RL32:      ; CALL OCCURS                     ; |159| 
           MVKL    .S1     _GetPendAngle,A0  ; |174| 
           MVKH    .S1     _GetPendAngle,A0  ; |174| 
;*----------------------------------------------------------------------------*
;*   SOFTWARE PIPELINE INFORMATION
;*      Disqualified loop: software pipelining disabled
;*----------------------------------------------------------------------------*
L9:    
           B       .S2X    A0                ; |174| 
           MVKL    .S2     RL38,B3           ; |174| 
           MVKH    .S2     RL38,B3           ; |174| 
           NOP             3
RL38:      ; CALL OCCURS                     ; |174| 
           MVKL    .S2     _sprintf,B4       ; |175| 
           MVKH    .S2     _sprintf,B4       ; |175| 
           B       .S2     B4                ; |175| 
           MVKL    .S1     SL4+0,A0          ; |175| 
           MV      .S2X    A4,B5             ; |174| 

           MVKH    .S1     SL4+0,A0          ; |175| 
||         STW     .D2T1   A4,*+SP(20)       ; |174| 

           MVKL    .S2     RL40,B3           ; |175| 
||         MVKL    .S1     _tmp_string,A4    ; |175| 
||         STW     .D2T2   B5,*+SP(8)        ; |175| 

           MVKH    .S2     RL40,B3           ; |175| 
||         STW     .D2T1   A0,*+SP(4)        ; |175| 
||         MVKH    .S1     _tmp_string,A4    ; |175| 

RL40:      ; CALL OCCURS                     ; |175| 
           MVKL    .S1     _Report,A0        ; |175| 
           MVKH    .S1     _Report,A0        ; |175| 
           B       .S2X    A0                ; |175| 
           MVKL    .S2     RL42,B3           ; |175| 
           MVKH    .S2     RL42,B3           ; |175| 
           NOP             3
RL42:      ; CALL OCCURS                     ; |175| 
           MVKL    .S1     0x20000a8,A0      ; |176| 
           MVKH    .S1     0x20000a8,A0      ; |176| 
           LDW     .D1T1   *A0,A0            ; |176| 
           MVKL    .S2     _sprintf,B4       ; |177| 
           MVKH    .S2     _sprintf,B4       ; |177| 
           B       .S2     B4                ; |177| 
           MVKL    .S2     _tmp_string,B5    ; |177| 

           MVKL    .S1     SL5+0,A0          ; |177| 
||         STW     .D2T1   A0,*+SP(24)       ; |176| 
||         MV      .L2X    A0,B6             ; |177| 

           MVKH    .S1     SL5+0,A0          ; |177| 
||         MVKH    .S2     _tmp_string,B5    ; |177| 

           STW     .D2T1   A0,*+SP(4)        ; |177| 
||         MVKL    .S2     RL44,B3           ; |177| 

           STW     .D2T2   B6,*+SP(8)        ; |177| 
||         MV      .S1X    B5,A4             ; |177| 
||         MVKH    .S2     RL44,B3           ; |177| 

RL44:      ; CALL OCCURS                     ; |177| 
           MVKL    .S1     _Report,A0        ; |177| 
           MVKH    .S1     _Report,A0        ; |177| 
           B       .S2X    A0                ; |177| 
           MVKL    .S2     RL46,B3           ; |177| 
           MVKH    .S2     RL46,B3           ; |177| 
           NOP             3
RL46:      ; CALL OCCURS                     ; |177| 
           MVKL    .S2     _WaitTFlagCnt,B4  ; |178| 
           MVKH    .S2     _WaitTFlagCnt,B4  ; |178| 
           B       .S2     B4                ; |178| 
           MVKL    .S2     RL48,B3           ; |178| 
           MVK     .S1     0x1f4,A4          ; |178| 
           MVKH    .S2     RL48,B3           ; |178| 
           NOP             2
RL48:      ; CALL OCCURS                     ; |178| 
           B       .S1     L9                ; |179| 
           MVKL    .S1     _GetPendAngle,A0  ; |174| 
           MVKH    .S1     _GetPendAngle,A0  ; |174| 
           NOP             3
           ; BRANCH OCCURS                   ; |179| 


;******************************************************************************
;* STRINGS                                                                    *
;******************************************************************************
	.sect	".const"
SL1:	.string	13,10,13,10,0
SL2:	.string	"Mechatronics Course %d",13,10,0
SL3:	.string	"FPGA Ver%2x.%02x",13,10,0
SL4:	.string	"Pendulum Angle: %d",13,10,0
SL5:	.string	"Cart Encoder: %d",13,10,0
;******************************************************************************
;* UNDEFINED EXTERNAL REFERENCES                                              *
;******************************************************************************
	.global	_sprintf
	.global	_InitUART
	.global	_Report
	.global	_InitUSBMon
	.global	_tmp_string
	.global	_TFlag
	.global	__divf
	.global	__remi
