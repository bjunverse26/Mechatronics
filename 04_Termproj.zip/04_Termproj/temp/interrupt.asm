;******************************************************************************
;* TMS320C6x ANSI C Codegen                                      Version 4.10 *
;* Date/Time created: Wed May 27 12:44:26 2026                                *
;******************************************************************************

;******************************************************************************
;* GLOBAL FILE PARAMETERS                                                     *
;*                                                                            *
;*   Architecture      : TMS320C670x                                          *
;*   Optimization      : Disabled                                             *
;*   Optimizing for    : Compile time, Ease of Development                    *
;*                       Based on options: no -o, no -ms                      *
;*   Endian            : Little                                               *
;*   Interrupt Thrshld : Disabled                                             *
;*   Memory Model      : Large                                                *
;*   Calls to RTS      : Far                                                  *
;*   Pipelining        : Disabled                                             *
;*   Memory Aliases    : Presume are aliases (pessimistic)                    *
;*   Debug Info        : No Debug Info                                        *
;*                                                                            *
;******************************************************************************

	.asg	A15, FP
	.asg	B14, DP
	.asg	B15, SP
	.global	$bss


	.sect	".cinit"
	.align	8
	.field  	4,32
	.field  	_TFlag+0,32
	.field  	0,32			; _TFlag @ 0
	.sect	".text"
	.global	_TFlag
_TFlag:	.usect	.far,4,4

	.sect	".cinit"
	.align	8
	.field  	4,32
	.field  	_ref+0,32
	.field  	0,32			; _ref @ 0
	.sect	".text"
	.global	_ref
_ref:	.usect	.far,4,4
	.global	_y
_y:	.usect	.far,4,4
	.global	_u
_u:	.usect	.far,4,4
	.global	_u_sat
_u_sat:	.usect	.far,4,4
	.global	_error
_error:	.usect	.far,4,4
_s_error:	.usect	.far,4,4
_p_error:	.usect	.far,4,4
	.global	_P_term
_P_term:	.usect	.far,4,4
	.global	_I_term
_I_term:	.usect	.far,4,4
	.global	_D_term
_D_term:	.usect	.far,4,4
;	acp6x -q -D_FAR_RTS=1 --large_model=3 --version=6701 -m --i_output_file C:\Users\W10\AppData\Local\Temp\TI11828_2 --template_info_file C:\Users\W10\AppData\Local\Temp\TI11828_3 --object_file interrupt.obj --opt_shell 9 interrupt.c -as -k -mr1 -ml3 -q -fstemp -fftemp -mv6701 interrupt.c 
	.sect	".text"
	.global	_ISRextint4

;******************************************************************************
;* FUNCTION NAME: _ISRextint4                                                 *
;*                                                                            *
;*   Regs Modified     :                                                      *
;*   Regs Used         :                                                      *
;*   Local Frame Size  : 0 Args + 0 Auto + 0 Save = 0 byte                    *
;******************************************************************************
_ISRextint4:
;** --------------------------------------------------------------------------*
           B       .S2     IRP               ; |11| 
           NOP             5
           ; BRANCH OCCURS                   ; |11| 


	.sect	".text"
	.global	_ISRextint5

;******************************************************************************
;* FUNCTION NAME: _ISRextint5                                                 *
;*                                                                            *
;*   Regs Modified     :                                                      *
;*   Regs Used         :                                                      *
;*   Local Frame Size  : 0 Args + 0 Auto + 0 Save = 0 byte                    *
;******************************************************************************
_ISRextint5:
;** --------------------------------------------------------------------------*
           B       .S2     IRP               ; |17| 
           NOP             5
           ; BRANCH OCCURS                   ; |17| 


	.sect	".text"
	.global	_c_int08

;******************************************************************************
;* FUNCTION NAME: _c_int08                                                    *
;*                                                                            *
;*   Regs Modified     :                                                      *
;*   Regs Used         :                                                      *
;*   Local Frame Size  : 0 Args + 0 Auto + 0 Save = 0 byte                    *
;******************************************************************************
_c_int08:
;** --------------------------------------------------------------------------*
           B       .S2     IRP               ; |29| 
           NOP             5
           ; BRANCH OCCURS                   ; |29| 


	.sect	".text"
	.global	_c_int09

;******************************************************************************
;* FUNCTION NAME: _c_int09                                                    *
;*                                                                            *
;*   Regs Modified     :                                                      *
;*   Regs Used         :                                                      *
;*   Local Frame Size  : 0 Args + 0 Auto + 0 Save = 0 byte                    *
;******************************************************************************
_c_int09:
;** --------------------------------------------------------------------------*
           B       .S2     IRP               ; |35| 
           NOP             5
           ; BRANCH OCCURS                   ; |35| 


	.sect	".text"
	.global	_ISRtimer0

;******************************************************************************
;* FUNCTION NAME: _ISRtimer0                                                  *
;*                                                                            *
;*   Regs Modified     : A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,B0,B1,B2,B3,B4,B5,B6,  *
;*                           B7,B8,B9,SP                                      *
;*   Regs Used         : A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,B0,B1,B2,B3,B4,B5,B6,  *
;*                           B7,B8,B9,SP                                      *
;*   Local Frame Size  : 0 Args + 0 Auto + 84 Save = 84 byte                  *
;******************************************************************************
_ISRtimer0:
;** --------------------------------------------------------------------------*
           STW     .D2T2   B9,*SP--(88)      ; |31| 
           STW     .D2T1   A3,*+SP(24)       ; |31| 
           STW     .D2T2   B4,*+SP(68)       ; |31| 
           STW     .D2T1   A0,*+SP(12)       ; |31| 
           STW     .D2T1   A4,*+SP(28)       ; |31| 
           STW     .D2T1   A5,*+SP(32)       ; |31| 
           STW     .D2T1   A6,*+SP(36)       ; |31| 
           STW     .D2T1   A7,*+SP(40)       ; |31| 
           STW     .D2T1   A8,*+SP(44)       ; |31| 
           STW     .D2T1   A9,*+SP(48)       ; |31| 
           STW     .D2T2   B0,*+SP(52)       ; |31| 
           STW     .D2T2   B1,*+SP(56)       ; |31| 
           STW     .D2T2   B2,*+SP(60)       ; |31| 
           STW     .D2T2   B3,*+SP(64)       ; |31| 
           STW     .D2T2   B5,*+SP(72)       ; |31| 
           STW     .D2T2   B6,*+SP(76)       ; |31| 
           STW     .D2T2   B7,*+SP(80)       ; |31| 
           STW     .D2T2   B8,*+SP(84)       ; |31| 

           MVK     .S1     1,A3              ; |37| 
||         MVKL    .S2     _TFlag,B4         ; |37| 
||         STW     .D2T1   A2,*+SP(20)       ; |31| 

           MVKH    .S2     _TFlag,B4         ; |37| 
||         MVKL    .S1     _TINTCnt,A0       ; |39| 
||         STW     .D2T1   A1,*+SP(16)       ; |31| 

           STW     .D2T1   A3,*B4            ; |37| 
||         MVKH    .S1     _TINTCnt,A0       ; |39| 

           LDW     .D1T1   *A0,A3            ; |39| 
           MVKL    .S2     RL0,B3            ; |41| 
           MVKH    .S2     RL0,B3            ; |41| 
           NOP             2

           MVKL    .S1     _GetPendAngle,A3  ; |41| 
||         ADD     .D1     1,A3,A4           ; |39| 

           MVKH    .S1     _GetPendAngle,A3  ; |41| 
           B       .S2X    A3                ; |41| 
           STW     .D1T1   A4,*A0            ; |39| 
           NOP             4
RL0:       ; CALL OCCURS                     ; |41| 
           MVKL    .S2     _y,B5             ; |41| 
           MVKL    .S2     _ref,B6           ; |42| 
           MVKH    .S2     _y,B5             ; |41| 
           MVKH    .S2     _ref,B6           ; |42| 

           STW     .D2T1   A4,*B5            ; |41| 
||         MVKL    .S2     _y,B4             ; |42| 

           MVKH    .S2     _y,B4             ; |42| 
||         LDW     .D2T2   *B6,B5            ; |42| 

           LDW     .D2T2   *B4,B7            ; |42| 
           MVKL    .S2     _s_error,B6       ; |43| 
           MVKL    .S2     _error,B4         ; |42| 
           MVKH    .S2     _error,B4         ; |42| 
           MVKL    .S1     _error,A0         ; |43| 
           SUB     .D2     B5,B7,B5          ; |42| 

           STW     .D2T2   B5,*B4            ; |42| 
||         MVKH    .S2     _s_error,B6       ; |43| 
||         MVKH    .S1     _error,A0         ; |43| 

           LDW     .D2T2   *B6,B4            ; |43| 
||         LDW     .D1T1   *A0,A0            ; |43| 

           NOP             4

           MVKL    .S1     _error,A0         ; |44| 
||         ADD     .S2X    A0,B4,B4          ; |43| 

           STW     .D2T2   B4,*B6            ; |43| 
||         MVKH    .S1     _error,A0         ; |44| 

           LDW     .D1T1   *A0,A0            ; |44| 
           MVKL    .S2     0x40266666,B4     ; |44| 
           MVKH    .S2     0x40266666,B4     ; |44| 
           NOP             2
           INTSP   .L1     A0,A0             ; |44| 
           NOP             3
           MPYSP   .M2X    A0,B4,B5          ; |44| 
           MVKL    .S1     _p_error,A3       ; |45| 
           MVKL    .S1     _P_term,A0        ; |44| 

           MVKH    .S1     _P_term,A0        ; |44| 
||         MVKL    .S2     _error,B4         ; |45| 

           MVKH    .S1     _p_error,A3       ; |45| 
||         STW     .D1T2   B5,*A0            ; |44| 
||         MVKH    .S2     _error,B4         ; |45| 

           LDW     .D1T1   *A3,A0            ; |45| 
||         LDW     .D2T2   *B4,B4            ; |45| 

           MVKL    .S2     _p_error,B5       ; |48| 
           MVKH    .S2     _p_error,B5       ; |48| 
           NOP             2
           SUB     .L1X    B4,A0,A0          ; |45| 
           INTSP   .L1     A0,A0             ; |45| 
           MVKL    .S2     0x3c23d70a,B4     ; |45| 
           MVKH    .S2     0x3c23d70a,B4     ; |45| 
           MVKL    .S1     _s_error,A3       ; |46| 
           MPYSP   .M2X    A0,B4,B4          ; |45| 
           MVKL    .S1     _D_term,A0        ; |45| 
           MVKH    .S1     _D_term,A0        ; |45| 
           MVKH    .S1     _s_error,A3       ; |46| 
           STW     .D1T2   B4,*A0            ; |45| 
           LDW     .D1T1   *A3,A0            ; |46| 
           MVKL    .S2     0x3fa66666,B4     ; |46| 
           MVKH    .S2     0x3fa66666,B4     ; |46| 
           NOP             2
           INTSP   .L1     A0,A0             ; |46| 
           NOP             3
           MPYSP   .M1X    A0,B4,A3          ; |46| 
           MVKL    .S2     _I_term,B4        ; |46| 
           MVKH    .S2     _I_term,B4        ; |46| 
           MVKL    .S1     _error,A0         ; |48| 

           MVKH    .S1     _error,A0         ; |48| 
||         STW     .D2T1   A3,*B4            ; |46| 

           LDW     .D1T2   *A0,B6            ; |48| 
           MVKL    .S2     _P_term,B4        ; |49| 
           MVKL    .S1     _D_term,A0        ; |49| 
           MVKH    .S2     _P_term,B4        ; |49| 
           MVKH    .S1     _D_term,A0        ; |49| 
           STW     .D2T2   B6,*B5            ; |48| 

           LDW     .D2T2   *B4,B4            ; |49| 
||         LDW     .D1T1   *A0,A3            ; |49| 

           MVKL    .S1     _I_term,A0        ; |49| 
           MVKH    .S1     _I_term,A0        ; |49| 
           LDW     .D1T1   *A0,A0            ; |49| 
           ZERO    .D2     B6                ; |52| 
           ADDSP   .L2X    A3,B4,B4          ; |49| 
           ZERO    .D1     A3                ; |51| 
           MVKH    .S1     0x42480000,A3     ; |51| 
           MVKH    .S2     0x42480000,B6     ; |52| 
           ADDSP   .L2X    A0,B4,B5          ; |49| 
           MVKL    .S2     _u,B4             ; |49| 
           MVKH    .S2     _u,B4             ; |49| 
           MVKL    .S1     _u,A0             ; |51| 

           STW     .D2T2   B5,*B4            ; |49| 
||         MVKH    .S1     _u,A0             ; |51| 

           LDW     .D1T1   *A0,A4            ; |51| 
           MVKL    .S2     _u,B4             ; |53| 
           MVKL    .S1     _u_sat,A0         ; |52| 
           ZERO    .D2     B5                ; |53| 
           MVKH    .S2     0xc2480000,B5     ; |53| 
           CMPGTSP .S1     A4,A3,A1          ; |51| 
   [ A1]   B       .S1     L1                ; |52| 
           MVKH    .S1     _u_sat,A0         ; |52| 
   [ A1]   STW     .D1T2   B6,*A0            ; |52| 
           MVKH    .S2     _u,B4             ; |53| 
           NOP             2
           ; BRANCH OCCURS                   ; |52| 
;** --------------------------------------------------------------------------*
           LDW     .D2T2   *B4,B4            ; |53| 
           MVKL    .S1     _u,A0             ; |56| 
           MVKH    .S1     _u,A0             ; |56| 
           ZERO    .D1     A3                ; |54| 
           MVKH    .S1     0xc2480000,A3     ; |54| 
           CMPLTSP .S2     B4,B5,B0          ; |53| 
   [!B0]   LDW     .D1T1   *A0,A0            ; |56| 
           MVKL    .S2     _u_sat,B5         ; |54| 
           MVKH    .S2     _u_sat,B5         ; |54| 
           MVKL    .S2     _u_sat,B4         ; |56| 

   [ B0]   STW     .D2T1   A3,*B5            ; |54| 
||         MVKH    .S2     _u_sat,B4         ; |56| 

   [!B0]   STW     .D2T1   A0,*B4            ; |56| 
;** --------------------------------------------------------------------------*
L1:    

           MVKL    .S2     _u_sat,B4         ; |58| 
||         MVKL    .S1     _PWMOut,A0        ; |58| 

           MVKH    .S2     _u_sat,B4         ; |58| 
||         MVKH    .S1     _PWMOut,A0        ; |58| 

           B       .S2X    A0                ; |58| 
           LDW     .D2T1   *B4,A4            ; |58| 
           MVKL    .S2     RL2,B3            ; |58| 
           MVKH    .S2     RL2,B3            ; |58| 
           NOP             2
RL2:       ; CALL OCCURS                     ; |58| 
           MVKL    .S1     _error,A0         ; |76| 
           MVKH    .S1     _error,A0         ; |76| 

           MVKL    .S1     _ref,A0           ; |76| 
||         LDW     .D1T1   *A0,A3            ; |76| 

           MVKH    .S1     _ref,A0           ; |76| 
           LDW     .D1T1   *A0,A0            ; |76| 
           MVKL    .S2     _y,B4             ; |76| 
           MVKH    .S2     _y,B4             ; |76| 
           LDW     .D2T2   *B4,B4            ; |76| 
           MVKL    .S2     _u_sat,B5         ; |76| 

           INTSP   .L1     A0,A4             ; |76| 
||         MVKL    .S1     _UMAddData,A0     ; |76| 

           MVKH    .S2     _u_sat,B5         ; |76| 
||         MVKH    .S1     _UMAddData,A0     ; |76| 

           B       .S2X    A0                ; |76| 
           LDW     .D2T2   *B5,B6            ; |76| 

           INTSP   .L2     B4,B4             ; |76| 
||         INTSP   .L1     A3,A6             ; |76| 

           MVKL    .S2     RL4,B3            ; |76| 
           MVKH    .S2     RL4,B3            ; |76| 
           NOP             1
RL4:       ; CALL OCCURS                     ; |76| 
           LDW     .D2T2   *+SP(84),B8       ; |77| 
           LDW     .D2T2   *+SP(80),B7       ; |77| 
           LDW     .D2T2   *+SP(60),B2       ; |77| 
           LDW     .D2T2   *+SP(56),B1       ; |77| 
           LDW     .D2T2   *+SP(52),B0       ; |77| 
           LDW     .D2T1   *+SP(48),A9       ; |77| 
           LDW     .D2T1   *+SP(44),A8       ; |77| 
           LDW     .D2T1   *+SP(40),A7       ; |77| 
           LDW     .D2T1   *+SP(32),A5       ; |77| 
           LDW     .D2T1   *+SP(20),A2       ; |77| 
           LDW     .D2T1   *+SP(16),A1       ; |77| 
           LDW     .D2T2   *+SP(72),B5       ; |77| 
           LDW     .D2T1   *+SP(24),A3       ; |77| 
           LDW     .D2T1   *+SP(12),A0       ; |77| 
           LDW     .D2T2   *+SP(64),B3       ; |77| 
           LDW     .D2T2   *+SP(68),B4       ; |77| 
           LDW     .D2T1   *+SP(36),A6       ; |77| 
           LDW     .D2T1   *+SP(28),A4       ; |77| 

           B       .S2     IRP               ; |77| 
||         LDW     .D2T2   *+SP(76),B6       ; |77| 

           LDW     .D2T2   *++SP(88),B9      ; |77| 
           NOP             4
           ; BRANCH OCCURS                   ; |77| 


	.sect	".text"
	.global	_ISRNMI

;******************************************************************************
;* FUNCTION NAME: _ISRNMI                                                     *
;*                                                                            *
;*   Regs Modified     :                                                      *
;*   Regs Used         :                                                      *
;*   Local Frame Size  : 0 Args + 0 Auto + 0 Save = 0 byte                    *
;******************************************************************************
_ISRNMI:
;** --------------------------------------------------------------------------*
           B       .S2     IRP               ; |81| 
           NOP             5
           ; BRANCH OCCURS                   ; |81| 


	.sect	".text"
	.global	_ISRextint6

;******************************************************************************
;* FUNCTION NAME: _ISRextint6                                                 *
;*                                                                            *
;*   Regs Modified     : A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,B0,B1,B2,B3,B4,B5,B6,  *
;*                           B7,B8,B9,SP                                      *
;*   Regs Used         : A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,B0,B1,B2,B3,B4,B5,B6,  *
;*                           B7,B8,B9,SP                                      *
;*   Local Frame Size  : 0 Args + 4 Auto + 84 Save = 88 byte                  *
;******************************************************************************
_ISRextint6:
;** --------------------------------------------------------------------------*
           STW     .D2T2   B9,*SP--(88)      ; |84| 
           STW     .D2T1   A0,*+SP(12)       ; |84| 
           STW     .D2T2   B7,*+SP(80)       ; |84| 
           STW     .D2T2   B6,*+SP(76)       ; |84| 
           STW     .D2T2   B5,*+SP(72)       ; |84| 
           STW     .D2T2   B4,*+SP(68)       ; |84| 
           STW     .D2T2   B3,*+SP(64)       ; |84| 
           STW     .D2T2   B2,*+SP(60)       ; |84| 
           STW     .D2T2   B1,*+SP(56)       ; |84| 
           STW     .D2T2   B0,*+SP(52)       ; |84| 
           STW     .D2T1   A9,*+SP(48)       ; |84| 
           STW     .D2T1   A8,*+SP(44)       ; |84| 
           STW     .D2T1   A7,*+SP(40)       ; |84| 
           STW     .D2T1   A6,*+SP(36)       ; |84| 
           STW     .D2T1   A5,*+SP(32)       ; |84| 
           STW     .D2T1   A4,*+SP(28)       ; |84| 
           STW     .D2T1   A3,*+SP(24)       ; |84| 
           STW     .D2T1   A2,*+SP(20)       ; |84| 

           STW     .D2T1   A1,*+SP(16)       ; |84| 
||         MVKL    .S1     0x2000008,A0      ; |87| 

           MVKH    .S1     0x2000008,A0      ; |87| 
||         STW     .D2T2   B8,*+SP(84)       ; |84| 

           LDW     .D1T1   *A0,A0            ; |87| 
           NOP             4
           AND     .S1     15,A0,A0          ; |87| 
           CMPEQ   .L1     A0,1,A1           ; |87| 
   [ A1]   B       .S1     L9                ; |87| 
           STW     .D2T1   A0,*+SP(4)        ; |87| 
   [ A1]   LDW     .D2T2   *+SP(80),B7       ; |121| 
   [ A1]   LDW     .D2T2   *+SP(76),B6       ; |121| 
   [ A1]   LDW     .D2T2   *+SP(72),B5       ; |121| 
   [ A1]   LDW     .D2T2   *+SP(68),B4       ; |121| 
           ; BRANCH OCCURS                   ; |87| 
;** --------------------------------------------------------------------------*
           LDW     .D2T2   *+SP(4),B4        ; |88| 
           NOP             3
;** --------------------------------------------------------------------------*
;**   BEGIN LOOP L2
;** --------------------------------------------------------------------------*
L2:    
           NOP             1
           CMPEQ   .L2     B4,4,B0           ; |88| 
   [!B0]   B       .S1     L4                ; |88| 

   [!B0]   LDW     .D2T2   *+SP(4),B4        ; |100| 
|| [ B0]   MVKL    .S1     0x2000014,A0      ; |89| 

   [ B0]   MVKH    .S1     0x2000014,A0      ; |89| 
   [ B0]   LDW     .D1T1   *A0,A0            ; |89| 
           NOP             2
           ; BRANCH OCCURS                   ; |88| 
;** --------------------------------------------------------------------------*
           NOP             2
           AND     .S1     1,A0,A1           ; |89| 
   [!A1]   B       .S1     L8                ; |89| 
   [!A1]   MVKL    .S1     0x2000008,A0      ; |120| 
   [!A1]   MVKH    .S1     0x2000008,A0      ; |120| 

   [ A1]   ZERO    .D2     B4                ; |90| 
|| [ A1]   MVKL    .S2     _compacket+124,B5 ; |90| 
|| [!A1]   LDW     .D1T1   *A0,A0            ; |120| 

   [ A1]   MVKH    .S2     0x2000000,B4      ; |90| 

   [ A1]   MVKH    .S2     _compacket+124,B5 ; |90| 
|| [ A1]   LDW     .D2T2   *B4,B4            ; |90| 

           ; BRANCH OCCURS                   ; |89| 
;** --------------------------------------------------------------------------*
           LDW     .D2T2   *B5,B5            ; |90| 
           NOP             1
;*----------------------------------------------------------------------------*
;*   SOFTWARE PIPELINE INFORMATION
;*      Disqualified loop: software pipelining disabled
;*----------------------------------------------------------------------------*
L3:    
           MVKL    .S1     _compacket+124,A0 ; |91| 
           MVKH    .S1     _compacket+124,A0 ; |91| 
           EXTU    .S2     B4,24,24,B4       ; |90| 
           STB     .D2T2   B4,*B5            ; |90| 
           LDW     .D1T1   *A0,A3            ; |91| 
           MVKL    .S1     _SendByte,A0      ; |91| 
           MVKH    .S1     _SendByte,A0      ; |91| 
           MVKL    .S2     RL6,B3            ; |91| 
           B       .S2X    A0                ; |91| 
           LDB     .D1T1   *A3,A4            ; |91| 
           MVKH    .S2     RL6,B3            ; |91| 
           NOP             3
RL6:       ; CALL OCCURS                     ; |91| 
           MVKL    .S2     _compacket+124,B4 ; |92| 
           MVKH    .S2     _compacket+124,B4 ; |92| 
           LDW     .D2T2   *B4,B4            ; |92| 
           MVKL    .S1     _compacket+99,A0  ; |92| 
           MVKH    .S1     _compacket+99,A0  ; |92| 
           NOP             2
           CMPEQ   .L1X    B4,A0,A1          ; |92| 
   [!A1]   MVKL    .S2     _compacket+124,B4 ; |96| 
   [!A1]   MVKH    .S2     _compacket+124,B4 ; |96| 
   [!A1]   LDW     .D2T2   *B4,B5            ; |96| 
   [ A1]   MVKL    .S2     _compacket+124,B4 ; |93| 
   [ A1]   MVKL    .S1     _compacket,A0     ; |93| 
   [ A1]   MVKH    .S2     _compacket+124,B4 ; |93| 
   [ A1]   MVKH    .S1     _compacket,A0     ; |93| 

           MVKL    .S2     0x2000014,B5      ; |98| 
|| [!A1]   ADD     .D2     1,B5,B6           ; |96| 

   [!A1]   STW     .D2T2   B6,*B4            ; |96| 

   [ A1]   STW     .D2T1   A0,*B4            ; |93| 
||         MVKH    .S2     0x2000014,B5      ; |98| 

           LDW     .D2T2   *B5,B4            ; |98| 
           NOP             4
           AND     .S2     1,B4,B0           ; |98| 
   [ B0]   B       .S1     L3                ; |98| 

   [ B0]   ZERO    .D2     B4                ; |90| 
|| [ B0]   MVKL    .S2     _compacket+124,B5 ; |90| 

   [ B0]   MVKH    .S2     0x2000000,B4      ; |90| 

   [ B0]   MVKH    .S2     _compacket+124,B5 ; |90| 
|| [ B0]   LDW     .D2T2   *B4,B4            ; |90| 

   [ B0]   LDW     .D2T2   *B5,B5            ; |90| 
           NOP             1
           ; BRANCH OCCURS                   ; |98| 
;** --------------------------------------------------------------------------*
           B       .S1     L8                ; |99| 
           MVKL    .S1     0x2000008,A0      ; |120| 
           MVKH    .S1     0x2000008,A0      ; |120| 
           LDW     .D1T1   *A0,A0            ; |120| 
           NOP             2
           ; BRANCH OCCURS                   ; |99| 
;** --------------------------------------------------------------------------*
L4:    
           CMPEQ   .L2     B4,2,B0           ; |100| 
   [!B0]   B       .S1     L5                ; |100| 
   [ B0]   MVKL    .S2     _respacket+200,B4 ; |101| 
           NOP             3
   [!B0]   LDW     .D2T2   *+SP(4),B4        ; |109| 
           ; BRANCH OCCURS                   ; |100| 
;** --------------------------------------------------------------------------*
           MVKH    .S2     _respacket+200,B4 ; |101| 
           LDW     .D2T2   *B4,B5            ; |101| 
           NOP             4
           CMPGT   .L2     B5,0,B0           ; |101| 

   [ B0]   MVKL    .S1     _respacket+204,A0 ; |102| 
||         SUB     .D2     B5,1,B5           ; |101| 

   [ B0]   MVKH    .S1     _respacket+204,A0 ; |102| 
||         STW     .D2T2   B5,*B4            ; |101| 

   [ B0]   LDW     .D1T1   *A0,A3            ; |102| 
   [ B0]   MVKL    .S1     _respacket,A4     ; |102| 
   [ B0]   MVKH    .S1     _respacket,A4     ; |102| 
   [!B0]   MVKL    .S1     0x2000004,A0      ; |105| 
   [!B0]   MVKL    .S2     _respacket+208,B4 ; |106| 
   [ B0]   ADD     .D1     1,A3,A5           ; |102| 
   [ B0]   STW     .D1T1   A5,*A0            ; |102| 

           B       .S1     L7                ; |108| 
|| [ B0]   LDB     .D1T1   *+A3[A4],A0       ; |102| 

   [!B0]   MVKH    .S1     0x2000004,A0      ; |105| 
   [!B0]   MVK     .S2     1,B5              ; |105| 

   [!B0]   ZERO    .D2     B5                ; |106| 
|| [ B0]   ZERO    .L2     B4                ; |102| 
|| [!B0]   MVKH    .S2     _respacket+208,B4 ; |106| 
|| [!B0]   STW     .D1T2   B5,*A0            ; |105| 

   [ B0]   MVKH    .S2     0x2000000,B4      ; |102| 
|| [!B0]   STW     .D2T2   B5,*B4            ; |106| 

   [ B0]   STW     .D2T1   A0,*B4            ; |102| 
           ; BRANCH OCCURS                   ; |108| 
;** --------------------------------------------------------------------------*
L5:    
           NOP             4
           CMPEQ   .L2     B4,12,B0          ; |109| 
   [!B0]   B       .S1     L7                ; |109| 
           NOP             2
   [ B0]   MVKL    .S1     0x2000014,A0      ; |110| 
   [ B0]   MVKH    .S1     0x2000014,A0      ; |110| 
   [ B0]   LDW     .D1T1   *A0,A0            ; |110| 
           ; BRANCH OCCURS                   ; |109| 
;** --------------------------------------------------------------------------*
           NOP             4
           AND     .S1     1,A0,A1           ; |110| 
   [!A1]   B       .S1     L7                ; |110| 
           NOP             4
   [ A1]   ZERO    .D2     B4                ; |111| 
           ; BRANCH OCCURS                   ; |110| 
;*----------------------------------------------------------------------------*
;*   SOFTWARE PIPELINE INFORMATION
;*      Disqualified loop: software pipelining disabled
;*----------------------------------------------------------------------------*
L6:    

           MVKH    .S2     0x2000000,B4      ; |111| 
||         MVKL    .S1     _compacket+124,A0 ; |111| 

           LDW     .D2T2   *B4,B4            ; |111| 
||         MVKH    .S1     _compacket+124,A0 ; |111| 

           LDW     .D1T1   *A0,A3            ; |111| 
           MVKL    .S1     _compacket+124,A0 ; |112| 
           MVKH    .S1     _compacket+124,A0 ; |112| 
           NOP             1
           EXTU    .S2     B4,24,24,B4       ; |111| 
           STB     .D1T2   B4,*A3            ; |111| 
           LDW     .D1T1   *A0,A0            ; |112| 
           MVKL    .S2     _compacket+99,B4  ; |112| 
           MVKH    .S2     _compacket+99,B4  ; |112| 
           NOP             2
           CMPEQ   .L2X    A0,B4,B0          ; |112| 
   [!B0]   MVKL    .S1     _compacket+124,A0 ; |116| 
   [!B0]   MVKH    .S1     _compacket+124,A0 ; |116| 
   [!B0]   MV      .D1     A0,A4             ; |116| 
   [!B0]   LDW     .D1T1   *A4,A0            ; |116| 
   [ B0]   MVKL    .S1     _compacket+124,A0 ; |113| 
   [ B0]   MVKL    .S2     _compacket,B4     ; |113| 
   [ B0]   MVKH    .S1     _compacket+124,A0 ; |113| 
   [ B0]   MVKH    .S2     _compacket,B4     ; |113| 

           MVKL    .S1     0x2000014,A0      ; |118| 
|| [!B0]   ADD     .L1     1,A0,A3           ; |116| 
|| [ B0]   STW     .D1T2   B4,*A0            ; |113| 

           MVKH    .S1     0x2000014,A0      ; |118| 
|| [!B0]   STW     .D1T1   A3,*A4            ; |116| 

           LDW     .D1T1   *A0,A0            ; |118| 
           NOP             4
           AND     .S1     1,A0,A1           ; |118| 
   [ A1]   B       .S1     L6                ; |118| 
           NOP             4
   [ A1]   ZERO    .D2     B4                ; |111| 
           ; BRANCH OCCURS                   ; |118| 
;** --------------------------------------------------------------------------*
L7:    
           MVKL    .S1     0x2000008,A0      ; |120| 
           MVKH    .S1     0x2000008,A0      ; |120| 
           LDW     .D1T1   *A0,A0            ; |120| 
           NOP             2
;** --------------------------------------------------------------------------*
L8:    
           NOP             2
           AND     .S1     15,A0,A0          ; |120| 
           CMPEQ   .L1     A0,1,A1           ; |120| 
   [!A1]   B       .S1     L2                ; |120| 
           STW     .D2T1   A0,*+SP(4)        ; |120| 
   [!A1]   LDW     .D2T2   *+SP(4),B4        ; |88| 
   [ A1]   LDW     .D2T2   *+SP(80),B7       ; |121| 
   [ A1]   LDW     .D2T2   *+SP(76),B6       ; |121| 
   [ A1]   LDW     .D2T2   *+SP(72),B5       ; |121| 
           ; BRANCH OCCURS                   ; |120| 
;** --------------------------------------------------------------------------*
           LDW     .D2T2   *+SP(68),B4       ; |121| 
;** --------------------------------------------------------------------------*
L9:    
           LDW     .D2T2   *+SP(64),B3       ; |121| 
           LDW     .D2T2   *+SP(60),B2       ; |121| 
           LDW     .D2T2   *+SP(56),B1       ; |121| 
           LDW     .D2T2   *+SP(52),B0       ; |121| 
           LDW     .D2T1   *+SP(48),A9       ; |121| 
           LDW     .D2T1   *+SP(44),A8       ; |121| 
           LDW     .D2T1   *+SP(40),A7       ; |121| 
           LDW     .D2T1   *+SP(36),A6       ; |121| 
           LDW     .D2T1   *+SP(32),A5       ; |121| 
           LDW     .D2T1   *+SP(28),A4       ; |121| 
           LDW     .D2T1   *+SP(24),A3       ; |121| 
           LDW     .D2T1   *+SP(20),A2       ; |121| 
           LDW     .D2T1   *+SP(16),A1       ; |121| 
           LDW     .D2T1   *+SP(12),A0       ; |121| 

           B       .S2     IRP               ; |121| 
||         LDW     .D2T2   *+SP(84),B8       ; |121| 

           LDW     .D2T2   *++SP(88),B9      ; |121| 
           NOP             4
           ; BRANCH OCCURS                   ; |121| 


;******************************************************************************
;* UNDEFINED EXTERNAL REFERENCES                                              *
;******************************************************************************
	.global	_PWMOut
	.global	_GetPendAngle
	.global	_SendByte
	.global	_UMAddData
	.global	_compacket
	.global	_respacket
	.global	_TINTCnt
