/* Interupt.c */

#include <c6x.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "c6701.h"
#include "constant.h"
#include "typedef.h"
#include "bss.h"
#include "function.h"
#include "interrupt.h"
#include "USBMon.h"

#define Kp_angle			(40.0f)
#define Kd_angle			(0.0f)
#define Ki_angle			(0.0f)

#define Kp_cart				(0.0f)
#define Kd_cart				(0.0f)
#define Ki_cart				(0.0f)

#define REF_THETA_DEG		(0.0f)
#define REF_CART_POS		(0.0f)
#define THETA_REF_LIMIT		(3.0f)

unsigned int TFlag = 0;

interrupt void ISRtimer0()
{
	// -------------------------------
	/* 2026.06.05 (금) - 진자 밸런싱 */
	// -------------------------------
	// 진자 PID 제어 변수
	float theta;
	float theta_ref;
	float theta_error;
	static float theta_p = 0.0f;
	static float theta_i = 0.0f;

	// 카트 PID 제어 변수 
	float x;
	float x_error;
	static float x_p = 0.0f;
	static float x_i = 0.0f;
	
	// 제어 입력 변수
	float pendulum_pid;
	float cart_pid;
	float u;
	float u_sat;

	TFlag = 1;

	TINTCnt++;
	
	// 현재 진자 각도 & 카트 위치 읽기
	theta = (float)GetAngle();
	x = (int)(*DC_ENC_POSCNT_R);

	// 초기 위치와의 오차 계산
	x_error = (float)x - REF_CART_POS;
	
	// Error 누적 (I gain 계산을 위함)
	x_i += x_error;

	// 본격적인 진자 & 카트 PID
	cart_pid = Kp_cart * x_error + Kd_cart * (x_error - x_p) + Ki_cart * x_i;

	theta_ref = REF_THETA_DEG + cart_pid;

	if (theta_ref > THETA_REF_LIMIT)
		theta_ref = THETA_REF_LIMIT;
	else if (theta_ref < -THETA_REF_LIMIT)
		theta_ref = -THETA_REF_LIMIT;

	theta_error = theta - theta_ref;
	theta_i += theta_error;

	pendulum_pid = Kp_angle * theta_error + Kd_angle * (theta_error - theta_p) + Ki_angle * theta_i;

	u = pendulum_pid;

	// 과거 Error 저장 (D gain 계산을 위함)
	theta_p = theta_error;
	x_p = x_error;

	if (u > 48.0f)
		u_sat = 48.0f;
	else if (u < -48.0f)
		u_sat = -48.0f;
	else
		u_sat = u;

	PWMOut(u_sat);

	UMAddData(theta_error, x_error, u, u_sat);	// Add 4 data set to USBMon
}

interrupt void ISRNMI()
{
}

interrupt void ISRextint6()
{
	volatile unsigned int tmp;

	while((tmp = *intid_fifo & 0x0F) != 1) {
		if(tmp == 0x04) {
			while(*linestatus&0x01) {
				*(compacket.wr_ptr) = *txrx_divl & 0xFF;
				SendByte(*(compacket.wr_ptr));
				if(compacket.wr_ptr == (compacket.packet+SIZE_OF_COMPACKET-1)) {
					compacket.wr_ptr = compacket.packet;
				}
				else {
					compacket.wr_ptr++;
				}
			}
		}
		else if(tmp == 0x02) {
			if(respacket.char_num-- > 0) {
				*txrx_divl = respacket.string[respacket.char_to_send++];
			}
			else {
				*inten_divh = 0x01;			
				respacket.flag = 0;
			}
		}
		else if(tmp == 0x0C) {
			while(*linestatus & 0x01) {
				*(compacket.wr_ptr) = *txrx_divl & 0xFF;
				if(compacket.wr_ptr == (compacket.packet+SIZE_OF_COMPACKET-1)) {
					compacket.wr_ptr = compacket.packet;
				}
				else {
					compacket.wr_ptr++;
				}
			}
		}
	}
}
